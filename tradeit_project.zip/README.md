Simple trade website using python & django
Models:
  User, Profile(extended User model with OneToOne), Product, Images (extended Product model with OneToOne), Cart
I don't use django forms
This is my first web project I need for my university, so I'll try to make it better.


Ivan Eresko, Otago Polytechnic, Auckland, New Zealand.
