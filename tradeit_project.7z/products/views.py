from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from .forms import ContactForm
from django.http import HttpResponseRedirect


def home(request):
    return render(request, 'products/home.html', {'title': 'Trade It'})


def details(request):
    return render(request, 'products/details.html')


def get_name(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            subject = form.cleaned_data['subject']
            message = form.cleaned_data['message']
            sender = form.cleaned_data['sender']
            cc_myself = form.cleaned_data['cc_myself']

            recipients = ['info@example.com']
            if cc_myself:
                recipients.append(sender)
            return HttpResponseRedirect('details')
    else:
        form = ContactForm()
    return render(request, 'products/details.html', {'form': form})

